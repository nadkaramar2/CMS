package sequro.filedownload;

public class Customer
{
    private String companyName;
    private String contactName;
    private String address;
    private String email;
    private String phone;
    private String base64ImgStr;

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getContactName() {
        return contactName;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
    
    public String getBase64ImgStr() {
		return base64ImgStr;
	}
    public void setBase64ImgStr(String base64ImgStr) {
		this.base64ImgStr = base64ImgStr;
	}

	@Override
	public String toString() {
		return "Customer [companyName=" + companyName + ", contactName=" + contactName + ", address=" + address
				+ ", email=" + email + ", phone=" + phone + "]";
	}
    
}
