package sequro.filedownload.pdf;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.thymeleaf.TemplateEngine;

import sequro.filedownload.Customer;
import sequro.filedownload.QuoteItem;
import sequro.filedownload.reponse.DownloadResponse;


public class TestingPdfFileDownloader
{
	@Autowired
    private TemplateEngine templateEngine;
	
	@Autowired
	private Environment environment;
	//--------------TESTING CODE----------------------------------- START	
		public DownloadResponse getDownloadedPath() 
		{
			DownloadResponse downloadResponse = new DownloadResponse();
			Map<String, Object> data = new HashMap<>();
			try 
			{
				String parentFolderPath = environment.getProperty("DOWNLOAD_FILE_FOLDER_PATH");
				System.out.println("parentFolderPath::"+parentFolderPath);
				
				data = createPDf();
				
				/*
				String result = generatePdfFile("quotation", data, parentFolderPath, "myFIRSTpdf");
				System.out.println(result);
				if (result!=null) 
				{
					downloadResponse.setResponseCode("S0000");
					downloadResponse.setResponseDesc(result);
				}
				*/
			}
			catch (Exception e) 
			{
				e.printStackTrace();
			}
			
			return downloadResponse;
		}
		
		private Map<String, Object> createPDf() 
		{
			System.out.println("Creating PDF File ........................");
			Map<String, Object> data = new HashMap<>();
	        Customer customer = new Customer();
	        customer.setCompanyName("Simple Solution");
	        customer.setContactName("John Doe");
	        customer.setAddress("123, Simple Street");
	        customer.setEmail("john@simplesolution.dev");
	        customer.setPhone("123 456 789");
	        data.put("header", customer);

	        List<QuoteItem> quoteItems = new ArrayList<>();
	        QuoteItem quoteItem1 = new QuoteItem();
	        quoteItem1.setDescription("Test Quote Item 1");
	        quoteItem1.setQuantity(1);
	        quoteItem1.setUnitPrice(100.0);
	        quoteItem1.setTotal(100.0);
	        quoteItems.add(quoteItem1);

	        QuoteItem quoteItem2 = new QuoteItem();
	        quoteItem2.setDescription("Test Quote Item 2");
	        quoteItem2.setQuantity(4);
	        quoteItem2.setUnitPrice(500.0);
	        quoteItem2.setTotal(2000.0);
	        quoteItems.add(quoteItem2);

	        QuoteItem quoteItem3 = new QuoteItem();
	        quoteItem3.setDescription("Test Quote Item 3");
	        quoteItem3.setQuantity(2);
	        quoteItem3.setUnitPrice(200.0);
	        quoteItem3.setTotal(400.0);
	        quoteItems.add(quoteItem3);

	        data.put("body", quoteItems);
	        
	        return data;
		}
		//--------------TESTING CODE----------------------------------- END
}
