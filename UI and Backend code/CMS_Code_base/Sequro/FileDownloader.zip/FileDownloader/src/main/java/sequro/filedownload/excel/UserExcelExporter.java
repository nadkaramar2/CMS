package sequro.filedownload.excel;

import org.springframework.stereotype.Component;

import sequro.filedownload.util.Utility;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

@Component
public class UserExcelExporter 
{
	private XSSFWorkbook workbook;
    private XSSFSheet sheet;
    
    List<String> headerKeyListForMap = new ArrayList<String>();
	List<String> headerNameListForTable = new ArrayList<String>();
    
    private List<User> listUsers;
    private String parentFolderPath;
    
    public String getParentFolderPath() {
		return parentFolderPath;
	}
    public void setParentFolderPath(String parentFolderPath) {
		this.parentFolderPath = parentFolderPath;
	}
    
    public UserExcelExporter() 
    {
    	workbook = new XSSFWorkbook();
    	sheet = workbook.createSheet("Users");
	}

	private void writeHeaderLine() 
    {
    	System.out.println("workbook::"+workbook);
        Row row = sheet.createRow(0);
         
        CellStyle style = workbook.createCellStyle();
        XSSFFont font = workbook.createFont();
        font.setBold(true);
        font.setFontHeight(16);
        style.setFont(font);
        style.setWrapText(true);
        
        createCell(row, 0, "User ID", style);      
        createCell(row, 1, "E-mail", style);       
        createCell(row, 2, "Full Name", style);    
        createCell(row, 3, "Password", style);
    }
	
	private void writeDataLines() 
    {
    	try 
    	{
    		CellStyle style = workbook.createCellStyle();
            XSSFFont font = workbook.createFont();
            font.setFontHeight(14);
            style.setFont(font);
                     
            int rowCount = 1;
			for (User user : listUsers) 
			{
				System.out.println("called--------------");
				System.out.println("rowCount::"+rowCount);
				System.out.println("user::"+user);
				if (user!=null) 
				{
					Row row = sheet.createRow(rowCount++); 
					System.out.println("row::"+row);
					int columnCount = 0;
				  
					createCell(row, columnCount++, user.getId(), style); 
					createCell(row,columnCount++, user.getEmail(), style); 
					createCell(row, columnCount++, user.getFullName(), style); 
					createCell(row, columnCount++, user.getPassword(), style);
				}  
			}
    	}
    	catch (Exception e) 
    	{
    		e.printStackTrace();
		}
    }
    
    private void createCell(final Row row, int columnCount, Object value, CellStyle style)
    {
        sheet.autoSizeColumn(columnCount);
        Cell cell = row.createCell(columnCount);
        if (value instanceof Integer) 
        {
            cell.setCellValue((Integer) value);
        }
        else if (value instanceof Boolean)
        {
            cell.setCellValue((Boolean) value);
        }
        else 
        {
            cell.setCellValue((String) value);
        }
        cell.setCellStyle(style);
    }
    
   
    
    public void export() 
    {
    	try 
    	{
    		//XSSFWorkbook workbook = new XSSFWorkbook();
    		listUsers = new ArrayList<User>();
    		
    		User user = new User();
    		user.setId(1);
    		user.setFullName("Sunny Soni");
    		user.setEmail("ssoni@sequrotechnologies.com");
    		user.setPassword("Test@123");
    		listUsers.add(user);
    		
    		User user1 = new User();
    		user1.setId(2);
    		user1.setFullName("Sagar Khawse");
    		user1.setEmail("sagark@sequrotechnologies.com");
    		user1.setPassword("sagar@123");
    		listUsers.add(user1); 
    		
    		User user2 = new User();
    		user2.setId(3);
    		user2.setFullName("Prashant Tyade");
    		user2.setEmail("prashantt@sequrotechnologies.com");
    		user2.setPassword("prashant-sequro@123");
    		listUsers.add(user2);
    		
    		writeHeaderLine();
    		writeDataLines();
    		
    		//String parentFolderPath = environment.getProperty("DOWNLOAD_FILE_FOLDER_PATH");
    		System.out.println("parentFolderPath::"+parentFolderPath);
    		
    		String excelFileName = "mynew_xls_file" + new Date().getTime() + ".xlsx";        	
    		String excelDirectory = parentFolderPath + File.separator + "xlsx" + File.separator;
    		
    		Utility.makeDirectoryIfNotExist(excelDirectory);
    		
    		FileOutputStream outputStream = new FileOutputStream(excelDirectory + excelFileName);
    		workbook.write(outputStream);
    		workbook.close();
    		
    		System.out.println("<<------------File CREATED SuccessFully------------->>");
    		
    		outputStream.close();
    	}
    	catch (Exception e)
    	{
    		e.printStackTrace();
		}
    }
    
    
    class User
    {
    	private Integer id;        
        private String email;         
        private String password;         
        private String fullName;
		public Integer getId() {
			return id;
		}
		public void setId(Integer id) {
			this.id = id;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		public String getFullName() {
			return fullName;
		}
		public void setFullName(String fullName) {
			this.fullName = fullName;
		}
		@Override
		public String toString() {
			return "User [id=" + id + ", email=" + email + ", password=" + password + ", fullName=" + fullName + "]";
		} 
    }
}
