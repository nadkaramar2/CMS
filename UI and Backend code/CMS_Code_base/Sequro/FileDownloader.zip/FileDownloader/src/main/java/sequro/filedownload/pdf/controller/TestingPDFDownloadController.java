package sequro.filedownload.pdf.controller;

import java.io.File;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import sequro.filedownload.Customer;
import sequro.filedownload.QuoteItem;

@RestController
@RequestMapping("/testing-export-pdf")
public class TestingPDFDownloadController 
{
	@RequestMapping(value = "/test", method = RequestMethod.GET)
	private ResponseEntity<?> test() 
	{
		try 
		{

			RestTemplate restTemplate = new RestTemplate();
			HttpHeaders headers = new HttpHeaders();
			
			headers = new HttpHeaders();
		    headers.setContentType(MediaType.APPLICATION_JSON);
		   
		    
		    String _url = "http://localhost:1170/FileDownloaderAPI/export-pdf/getDownloadFile";
		    
			/*
			 * JSONObject jsonObj = new JSONObject(); jsonObj.put("deviceId","");
			 * jsonObj.put("merchantAlias", "TRENDIT_4G_SACHIN_02_78");
			 * jsonObj.put("orderId", "10001"); jsonObj.put("amount", "1590");
			 */
		    
		    Map<String, Object> data = new HashMap<>();
	        
		    Customer customer = new Customer();
	        customer.setCompanyName("Simple Solution");
	        customer.setContactName("John Doe");
	        customer.setAddress("123, Simple Street");
	        customer.setEmail("john@simplesolution.dev");
	        customer.setPhone("123 456 789");
	        
	        byte[] fileContent = FileUtils.readFileToByteArray(new File("E:\\Sequro\\Speta\\logo\\cbimage.png"));			
			String encodeString = Base64.getEncoder().encodeToString(fileContent);
			customer.setBase64ImgStr(encodeString);
	        
	        List<QuoteItem> quoteItems = new ArrayList<>();
	        QuoteItem quoteItem1 = new QuoteItem();
	        quoteItem1.setDescription("Test Quote Item 1");
	        quoteItem1.setQuantity(1);
	        quoteItem1.setUnitPrice(100.0);
	        quoteItem1.setTotal(100.0);
	        quoteItems.add(quoteItem1);

	        QuoteItem quoteItem2 = new QuoteItem();
	        quoteItem2.setDescription("Test Quote Item 2");
	        quoteItem2.setQuantity(4);
	        quoteItem2.setUnitPrice(500.0);
	        quoteItem2.setTotal(2000.0);
	        quoteItems.add(quoteItem2);

	        QuoteItem quoteItem3 = new QuoteItem();
	        quoteItem3.setDescription("Test Quote Item 3");
	        quoteItem3.setQuantity(2);
	        quoteItem3.setUnitPrice(200.0);
	        quoteItem3.setTotal(400.0);
	        quoteItems.add(quoteItem3);

	        data.put("bodyInfoInList", quoteItems);	        
	        data.put("headerInfoMap", customer);
	        data.put("templateName", "quotation");
	        data.put("fileName", "mypdf-");
	        
		    
		    HttpEntity<Map<String, Object>> request = new HttpEntity<Map<String, Object>>(data, headers);
		    
		    System.out.println("Calling .....processToGETDownloadedFile Request");
		    
		    String personResultAsJsonStr = restTemplate.postForObject(_url, request, String.class);
		    System.out.println("personResultAsJsonStr::"+personResultAsJsonStr);
		    return ResponseEntity.ok(personResultAsJsonStr);
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		return ResponseEntity.ok(null);
	}
}
