package sequro.filedownload.util;

import java.io.File;
import java.util.Base64;

import org.apache.commons.io.FileUtils;

public class Utility 
{
	public static void makeDirectoryIfNotExist(String directoryPath) 
	{
		try
		{
			File directory = new File(directoryPath);
			
			if (!directory.exists()) 
			{
				directory.mkdirs();
				System.out.println("Directory Created....");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static String getSequroBase64Image() {
		//return getBase64Image("D:\\Sequro\\Speta\\logo\\cbimage.png");
		return getBase64Image("/usr/local/tomcat/paths/Sequro/Speta/logo/cbimage.png");
	}
	
	public static String getBase64Image(String imageFileLocation) 
	{
		try 
		{
			File file = new File(imageFileLocation);
			//new File("E:\\Sequro\\Speta\\logo\\cbimage.png")
			if (!file.exists())
			{
				return null;
			}
			
			byte[] fileContent = FileUtils.readFileToByteArray(file);		
			String encodeString = Base64.getEncoder().encodeToString(fileContent);
			return encodeString;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		return null;
	}
}
