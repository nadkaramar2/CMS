package sequro.filedownload.csv.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/export-csv")
public class CSVDownloadController 
{

}
