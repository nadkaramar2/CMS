package sequro.filedownload.pdf.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import sequro.filedownload.pdf.PdfFileDownloader;
import sequro.filedownload.reponse.DownloadResponse;
import sequro.filedownload.util.Base64ImageReq;
import sequro.filedownload.util.FileDownloadRequest;
import sequro.filedownload.util.Utility;

@PropertySource("classpath:application.properties")
@RestController
@RequestMapping("/export-pdf")
public class PDFDownloadController 
{
	@Autowired
	PdfFileDownloader pdfFileDownloader;
	
	@Autowired
	private Environment environment;
	
	@RequestMapping(value = "/getDownloadFile", method = RequestMethod.POST)
	private ResponseEntity<?> processToGETDownloadedFile(@RequestBody FileDownloadRequest fileDownloadRequest) 
	{
		try
		{
			//DownloadResponse downloadResponse =  pdfFileDownloader.getDownloadedPath();			
			String base64ImageStr = "";
			Base64ImageReq base64ImageReq = new Base64ImageReq();
			if(fileDownloadRequest.getLogoImageLocation()!=null)
			{
				String imageLocation = fileDownloadRequest.getLogoImageLocation();
				base64ImageStr = Utility.getBase64Image(imageLocation);
			}
			else
			{
				//String defaultImageLocation = environment.getProperty("/usr/local/tomcat/paths/Sequro/Speta/logo/")+"cbimage.png";
				String defaultImageLocation = environment.getProperty("LOGO_IMAGE_PATH")+"cbimage.png";
				base64ImageStr = Utility.getBase64Image(defaultImageLocation);
				//base64ImageStr = Utility.getSequroBase64Image();
			}
			base64ImageReq.setBase64ImgStr(base64ImageStr);
			fileDownloadRequest.setBase64ImageReq(base64ImageReq);
			
			DownloadResponse downloadResponse = pdfFileDownloader.getDownloadedPath(fileDownloadRequest);
			System.out.println(downloadResponse);
			if (downloadResponse!=null) 
			{
				return ResponseEntity.ok(downloadResponse.getResponseDesc());
			}
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		return ResponseEntity.ok(null);
	}
	
}
