package sequro.filedownload.pdf;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;
import org.xhtmlrenderer.pdf.ITextRenderer;

import com.lowagie.text.DocumentException;
import sequro.filedownload.reponse.DownloadResponse;
import sequro.filedownload.util.FileDownloadRequest;
import sequro.filedownload.util.Utility;


@Component
@PropertySource("classpath:application.properties")
public class PdfFileDownloader 
{
	@Autowired
    private TemplateEngine templateEngine;
	
	@Autowired
	private Environment environment;
	
	public DownloadResponse getDownloadedPath(FileDownloadRequest fileDownloadRequest) 
	{
		DownloadResponse downloadResponse = new DownloadResponse();
		try 
		{
			//String parentFolderPath = "/usr/local/tomcat/paths/Sequro/Speta/downloadFile";
			String parentFolderPath = environment.getProperty("DOWNLOAD_FILE_FOLDER_PATH");
			System.out.println("parentFolderPath::"+parentFolderPath);
			
			Map<String, Object> mainMapData = creatingPDfMapData(fileDownloadRequest);
			String result = generatePdfFile(fileDownloadRequest.getTemplateName(), mainMapData, parentFolderPath, fileDownloadRequest.getFileName());
			System.out.println(result);
			if (result != null) 
			{
				downloadResponse.setResponseCode("S0000");
				downloadResponse.setResponseDesc(result);
			}
			else 
			{
				downloadResponse.setResponseCode("E0000");
				downloadResponse.setResponseDesc("Error:"+result);
			}
		}
		catch (Exception e) 
		{
			downloadResponse.setResponseCode("EX000");
			downloadResponse.setResponseDesc("Exception:"+e);
			e.printStackTrace();
		}
		return downloadResponse;
	}
	private Map<String, Object> creatingPDfMapData(FileDownloadRequest fileDownloadRequest)
	{
		Map<String, Object> resultMapdata = new HashMap<>();
		try
		{
			if (fileDownloadRequest.getHeaderInfoMap()!=null)
			{
				resultMapdata.put("header", fileDownloadRequest.getHeaderInfoMap().get("header"));
			}
			if (fileDownloadRequest.getBase64ImageReq()!=null)
			{
				resultMapdata.put("logo", fileDownloadRequest.getBase64ImageReq());
			}
			if(fileDownloadRequest.getBodyInfoInList()!=null)
			{
				resultMapdata.put("body", fileDownloadRequest.getBodyInfoInList());
			}
			if(fileDownloadRequest.getFooterInfoMap()!=null)
			{
				resultMapdata.put("footer", fileDownloadRequest.getFooterInfoMap().get("footer"));
			}
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		return resultMapdata;
	}
	
	private String generatePdfFile(final String templateName, final Map<String, Object> data, final String folderPath, final String fileName) 
	{
		String responseStr = "";
        Context context = new Context();
        try 
        {
        	context.setVariables(data);        	
        	String htmlContent = templateEngine.process(templateName, context);
        	
        	String pdfFileName = fileName + new Date().getTime() + ".pdf";        	
            String pdfDirectory = folderPath + File.separator + "pdf" + File.separator;            
            
            Utility.makeDirectoryIfNotExist(pdfDirectory);
        
            FileOutputStream fileOutputStream = new FileOutputStream(pdfDirectory + pdfFileName);
            ITextRenderer renderer = new ITextRenderer();
            renderer.setDocumentFromString(htmlContent);
            renderer.layout();
            renderer.createPDF(fileOutputStream, false);
            renderer.finishPDF();
            responseStr = "fileName="+pdfFileName;
            
            if (fileOutputStream!=null)
            {
            	fileOutputStream.close();
            }
        }
        catch (FileNotFoundException e) 
        {
            System.out.println(e.getMessage());
        } 
        catch (DocumentException e) 
        {
        	System.out.println(e.getMessage());
        }
        catch (IOException e) {
        	e.printStackTrace();
        }
        return responseStr;	
    }

}
