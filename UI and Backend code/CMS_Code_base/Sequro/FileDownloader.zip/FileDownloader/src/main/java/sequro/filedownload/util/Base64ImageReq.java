package sequro.filedownload.util;

public class Base64ImageReq 
{
	private String base64ImgStr;
	
	public String getBase64ImgStr() {
		return base64ImgStr;
	}
	public void setBase64ImgStr(String base64ImgStr) {
		this.base64ImgStr = base64ImgStr;
	}
}
