package sequro.filedownload.excel;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;

import sequro.filedownload.util.FileDownloadRequest;
import sequro.filedownload.util.Utility;

@Component
public class ExcelFileGenerator {
	@Autowired
	ObjectMapper mapper;

	private XSSFWorkbook workbook;
	private XSSFSheet sheet;

	List<String> headerKeyListForMap = new ArrayList<String>();
	HashMap<String, Object> headerInfoMap;
	List<Object> bodyInfoInList;

	public String createExcelFile(FileDownloadRequest fileDownloadRequest) 
	{
		try 
		{
			workbook = new XSSFWorkbook();
			sheet = workbook.createSheet("Users");

			System.out.println("fileDownloadRequest::" + fileDownloadRequest);
			System.out.println("HeaderInfoMap::" + fileDownloadRequest.getHeaderInfoMap());

			if (headerInfoMap != null) {
				headerInfoMap.clear();
			}
			if (bodyInfoInList != null) {
				bodyInfoInList.clear();
			}
			headerInfoMap = fileDownloadRequest.getHeaderInfoMap();
			bodyInfoInList = fileDownloadRequest.getBodyInfoInList();
			writeHeaderLine();

			writeDataLines();

			String downloadPath = fileDownloadRequest.getDownloadFolderPath();
			System.out.println("parentFolderPath::" + downloadPath);

			String excelFileName = fileDownloadRequest.getFileName() + new Date().getTime() + ".xlsx";
			String excelDirectory = downloadPath + File.separator + "xlsx" + File.separator;

			Utility.makeDirectoryIfNotExist(excelDirectory);

			FileOutputStream outputStream = new FileOutputStream(excelDirectory + excelFileName);
			workbook.write(outputStream);
			workbook.close();

			System.out.println("<<------------File CREATED SuccessFully------------->>");

			outputStream.close();

			return "fileName=" + excelFileName;
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			System.out.println("exception::" + e);
		}
		return null;
	}

	private void writeHeaderLine() {
		try {
			System.out.println("workbook::" + workbook);
			Row row = sheet.createRow(0);

			CellStyle style = workbook.createCellStyle();
			XSSFFont font = workbook.createFont();
			font.setBold(true);
			font.setFontHeight(16);
			style.setFont(font);
			style.setWrapText(true);
			Set<Entry<String, Object>> entrymap = headerInfoMap.entrySet();
			int columnCount = 0;
			// added by sunil Y clearing the map because is was adding duplicate header
			// every click of download excel 19-May-23 START
			headerKeyListForMap.clear();
			// added by sunil Y clearing the map because is was adding duplicate header
			// every click of download excel 19-May-23 END
			for (Entry<String, Object> it : entrymap) {
				String key = it.getKey();
				headerKeyListForMap.add(key);
				String value = (String) it.getValue();
				createCell(row, columnCount++, value, style);
			}
			System.out.println("headerKeyListForMap::" + headerKeyListForMap);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void writeDataLines() {
		try {
			XSSFFont font = workbook.createFont();
			font.setFontHeight(14);
			int rowCount = 1;

			String requestBodyStr = mapper.writeValueAsString(bodyInfoInList);
			System.out.println(requestBodyStr);

			JSONParser jsonParser = new JSONParser();
			Object obj = jsonParser.parse(requestBodyStr);
			if (obj instanceof JSONArray) {
				JSONArray jsonArr = (JSONArray) obj;
				for (int i = 0; i < jsonArr.size(); i++) {
					Row row = sheet.createRow(rowCount++);

					JSONObject jsonObj = (JSONObject) jsonArr.get(i);
					int columnCount = 0;

					for (String key : headerKeyListForMap) {
						//changed the place of cellstyle because it was wrong 
						CellStyle style = workbook.createCellStyle();
						style.setFont(font);
						Object objct = jsonObj.get(key);
						String columnValue = "";

						if (objct instanceof String) {
							columnValue = (String) objct;
						}

						else if (objct instanceof Integer) {
							columnValue = String.valueOf((Integer) objct);
						}

						else if (objct instanceof Long) {
							columnValue = String.valueOf((Long) objct);
						}

						else if (objct instanceof Double) {
							columnValue = String.valueOf((Double) objct);
						}

						else if (objct instanceof Float) {
							columnValue = String.valueOf((Float) objct);
						}

						else if (objct instanceof Boolean) {
							columnValue = String.valueOf((Boolean) objct);
						}
						//added By Sunil Y ,amount alignment to right , Started 
						if (key.equalsIgnoreCase("strTransaction_amount") || key.equalsIgnoreCase("strDebitAmount")
								|| key.equalsIgnoreCase("strClosingBalance")
								|| key.equalsIgnoreCase("strAmoutToTransfer") || key.equalsIgnoreCase("strTxnAmount")||key.equalsIgnoreCase("strAmount")) {
							style.setAlignment(HorizontalAlignment.RIGHT);
						} else {
							style.setAlignment(HorizontalAlignment.LEFT);
						}
						System.out.println("colName::" + columnValue);

						createCell(row, columnCount++, columnValue, style);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void createCell(final Row row, int columnCount, Object value, CellStyle style) {
		sheet.autoSizeColumn(columnCount);
		Cell cell = row.createCell(columnCount);
		// added by Sunil Y , if the value will be empty add "-"
		if (value.equals("")) {
			cell.setCellValue("-");
		} else if (value instanceof Integer) {
			cell.setCellValue((Integer) value);
		} else if (value instanceof Boolean) {
			cell.setCellValue((Boolean) value);
		} else {
			cell.setCellValue((String) value);
		}
		System.out.println("StyleAlignment::" + style.getAlignment().toString());
		cell.setCellStyle(style);
		System.out.println("StyleAlignment::" + style.getAlignment().toString());
	}

}
