package sequro.filedownload.util;

import java.io.Serializable;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;


@JsonInclude(value = JsonInclude.Include.NON_EMPTY)
public class FileDownloadRequest implements Serializable
{
	private static final long serialVersionUID = 1L;
	
	private LinkedHashMap<String, Object> headerInfoMap;
	
	private HashMap<String, Object> footerInfoMap;
	
	private Base64ImageReq base64ImageReq;
	
	private List<Object> bodyInfoInList;
	
	private String templateName;
	
	private String folderPath;
	
	private String fileName;
	
	private String downloadFolderPath;
	
	private String logoImageLocation;
	
	public HashMap<String, Object> getHeaderInfoMap() {
		return headerInfoMap;
	}

	
	public HashMap<String, Object> getFooterInfoMap() {
		return footerInfoMap;
	}

	public void setHeaderInfoMap(LinkedHashMap<String, Object> headerInfoMap) {
		this.headerInfoMap = headerInfoMap;
	}


	public void setFooterInfoMap(HashMap<String, Object> footerInfoMap) {
		this.footerInfoMap = footerInfoMap;
	}

	public Base64ImageReq getBase64ImageReq() {
		return base64ImageReq;
	}
	
	public void setBase64ImageReq(Base64ImageReq base64ImageReq) {
		this.base64ImageReq = base64ImageReq;
	}
	
	public String getTemplateName() {
		return templateName;
	}

	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

	public String getFolderPath() {
		return folderPath;
	}

	public void setFolderPath(String folderPath) {
		this.folderPath = folderPath;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	
	public List<Object> getBodyInfoInList() {
		return bodyInfoInList;
	}
	
	public void setBodyInfoInList(List<Object> bodyInfoInList) {
		this.bodyInfoInList = bodyInfoInList;
	}
	
	public String getDownloadFolderPath() {
		return downloadFolderPath;
	}
	
	public void setDownloadFolderPath(String downloadFolderPath) {
		this.downloadFolderPath = downloadFolderPath;
	}
	
	public String getLogoImageLocation() {
		return logoImageLocation;
	}
	
	public void setLogoImageLocation(String logoImageLocation) {
		this.logoImageLocation = logoImageLocation;
	}
}
