package sequro.filedownload.excel.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;

import sequro.filedownload.QuoteItem;
import sequro.filedownload.excel.UserExcelExporter;

@RestController
@RequestMapping("/test-export-excel")
public class TestingExcelFileController
{
	@Autowired
	private Environment environment;
	
	@Autowired
	ObjectMapper mapper;
	
	@RequestMapping(value = "/test0", method = RequestMethod.GET)
	private ResponseEntity<?> testXls() 
	{
		try 
		{
			//excelFileGenerator.createExcelFile("tempxls_");
			String parentFolderPath = environment.getProperty("DOWNLOAD_FILE_FOLDER_PATH");
			System.out.println("parentFolderPath::"+parentFolderPath);
			UserExcelExporter userExcelExporter = new UserExcelExporter();
			userExcelExporter.setParentFolderPath(parentFolderPath);
			userExcelExporter.export();
			return ResponseEntity.ok("Success");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return ResponseEntity.ok("failure");
	}
	
	@RequestMapping(value = "/test1", method = RequestMethod.POST)
	private ResponseEntity<?> testX1ls(@RequestBody Object object) 
	{
		try 
		{
			System.out.println(object);
			
			String requestStr = mapper.writeValueAsString(object);
			
			System.out.println(requestStr);
			
			JSONParser jsonParser = new JSONParser();
			
			Object obj = jsonParser.parse(requestStr);
			
			if (obj instanceof JSONObject) 
			{ 
				JSONObject json = (JSONObject) obj;
				for (Object keyObj : json.keySet()) 
				{
					String key = (String)keyObj;
					System.out.println(key);
					Object valObj = json.get(key);
					System.out.println(valObj);
				}				
			}
			else
			{
				JSONArray jsonArr = (JSONArray) obj;
				if(jsonArr.get(0) instanceof JSONObject)
				{
					JSONObject jsonobj = (JSONObject) jsonArr.get(0);
					for (Object keyObject : jsonobj.keySet()) 
					{
						String key = (String)keyObject;
						System.out.println(key);
					}
				}
			}
			
			//excelFileGenerator.createExcelFile("tempxls_");
			String parentFolderPath = environment.getProperty("DOWNLOAD_FILE_FOLDER_PATH");
			System.out.println("parentFolderPath::"+parentFolderPath);
			
			UserExcelExporter userExcelExporter = new UserExcelExporter();
			userExcelExporter.setParentFolderPath(parentFolderPath);
			userExcelExporter.export();
			return ResponseEntity.ok("Success");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return ResponseEntity.ok("failure");
	}
	
	@RequestMapping(value = "/test2", method = RequestMethod.GET)
	private ResponseEntity<?> test2() 
	{
		try 
		{
			RestTemplate restTemplate = new RestTemplate();
			HttpHeaders headers = new HttpHeaders();
			
			headers = new HttpHeaders();
		    headers.setContentType(MediaType.APPLICATION_JSON);
		   
		    
		    String _url = "http://localhost:1170/FileDownloaderAPI/export-excel/test1";
		    
		    List<QuoteItem> quoteItems = new ArrayList<>();
	        QuoteItem quoteItem1 = new QuoteItem();
	        quoteItem1.setDescription("Test Quote Item 1");
	        quoteItem1.setQuantity(1);
	        quoteItem1.setUnitPrice(100.0);
	        quoteItem1.setTotal(100.0);
	        quoteItems.add(quoteItem1);

	        QuoteItem quoteItem2 = new QuoteItem();
	        quoteItem2.setDescription("Test Quote Item 2");
	        quoteItem2.setQuantity(4);
	        quoteItem2.setUnitPrice(500.0);
	        quoteItem2.setTotal(2000.0);
	        quoteItems.add(quoteItem2);

	        QuoteItem quoteItem3 = new QuoteItem();
	        quoteItem3.setDescription("Test Quote Item 3");
	        quoteItem3.setQuantity(2);
	        quoteItem3.setUnitPrice(200.0);
	        quoteItem3.setTotal(400.0);
	        quoteItems.add(quoteItem3);
		    
	        HttpEntity<List<QuoteItem>> request = new HttpEntity<List<QuoteItem>>(quoteItems, headers);
		    
		    System.out.println("Calling .....processToGETDownloadedFile Request");
		    
		    String personResultAsJsonStr = restTemplate.postForObject(_url, request, String.class);
		    System.out.println("personResultAsJsonStr::"+personResultAsJsonStr);
		    return ResponseEntity.ok(personResultAsJsonStr);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return ResponseEntity.ok(null);
	}
	
	@RequestMapping(value = "/test", method = RequestMethod.GET)
	private ResponseEntity<?> test() 
	{
		try 
		{

			RestTemplate restTemplate = new RestTemplate();
			HttpHeaders headers = new HttpHeaders();
			
			headers = new HttpHeaders();
		    headers.setContentType(MediaType.APPLICATION_JSON);
		   
		    
		    String _url = "http://localhost:1170/FileDownloaderAPI/export-excel/getDownloadFile";
		    
		    Map<String, Object> data = new HashMap<>();
	        
		    //key contains mapping data for getting value and value contains header name
		    Map<String, String> headerDataMap = new HashMap<>();
		    headerDataMap.put("description", "DP");
		    headerDataMap.put("quantity", "QT");
		    headerDataMap.put("unitPrice", "UP");
		    headerDataMap.put("total", "TL");
	        
	        /*
	        byte[] fileContent = FileUtils.readFileToByteArray(new File("E:\\Sequro\\Speta\\logo\\cbimage.png"));			
			String encodeString = Base64.getEncoder().encodeToString(fileContent);
			customer.setBase64ImgStr(encodeString);
			*/
	        
	        List<QuoteItem> bodyData = new ArrayList<>();
	        QuoteItem quoteItem1 = new QuoteItem();
	        quoteItem1.setDescription("Test Quote Item 1");
	        quoteItem1.setQuantity(1);
	        quoteItem1.setUnitPrice(100.0);
	        quoteItem1.setTotal(100.0);
	        bodyData.add(quoteItem1);

	        QuoteItem quoteItem2 = new QuoteItem();
	        quoteItem2.setDescription("Test Quote Item 2");
	        quoteItem2.setQuantity(4);
	        quoteItem2.setUnitPrice(500.0);
	        quoteItem2.setTotal(2000.0);
	        bodyData.add(quoteItem2);

	        QuoteItem quoteItem3 = new QuoteItem();
	        quoteItem3.setDescription("Test Quote Item 3");
	        quoteItem3.setQuantity(2);
	        quoteItem3.setUnitPrice(200.0);
	        quoteItem3.setTotal(400.0);
	        bodyData.add(quoteItem3);

	        data.put("bodyInfoInList", bodyData);
	        data.put("headerInfoMap", headerDataMap);
	        data.put("fileName", "myexcel-");
	        
		    
		    HttpEntity<Map<String, Object>> request = new HttpEntity<Map<String, Object>>(data, headers);
		    
		    System.out.println("Calling .....processToGETDownloadedFile Request");
		    
		    String personResultAsJsonStr = restTemplate.postForObject(_url, request, String.class);
		    System.out.println("personResultAsJsonStr::"+personResultAsJsonStr);
		    return ResponseEntity.ok(personResultAsJsonStr);
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		return ResponseEntity.ok(null);
	}
}
