package sequro.filedownload.csv;

import org.springframework.stereotype.Component;

@Component
public class CsvFileDownloader 
{

}
