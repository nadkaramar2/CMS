package sequro.filedownload.excel.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import sequro.filedownload.excel.ExcelFileGenerator;
import sequro.filedownload.reponse.DownloadResponse;
import sequro.filedownload.util.FileDownloadRequest;

@PropertySource("classpath:application.properties")
@RestController
@RequestMapping("/export-excel")
public class ExcelFileController 
{
	@Autowired
	private ExcelFileGenerator excelFileGenerator;
	
	@Autowired
	private Environment environment;
	
	@RequestMapping(value = "/getDownloadFile", method = RequestMethod.POST)
	private ResponseEntity<?> processToGETDownloadedFile(@RequestBody FileDownloadRequest fileDownloadRequest) 
	{
		DownloadResponse downloadResponse = new DownloadResponse();
		try 
		{
			//String downloadFolderPath = "/usr/local/tomcat/paths/Sequro/Speta/downloadFile";
			String downloadFolderPath = environment.getProperty("DOWNLOAD_FILE_FOLDER_PATH");
			System.out.println("parentFolderPath::"+downloadFolderPath);			
			fileDownloadRequest.setDownloadFolderPath(downloadFolderPath);
			String responseStr = excelFileGenerator.createExcelFile(fileDownloadRequest);			
			return ResponseEntity.ok(responseStr);
		}
		catch (Exception e) 
		{
			downloadResponse.setResponseCode("EX000");
			downloadResponse.setResponseDesc("Exception:"+e);
			e.printStackTrace();
		}
		return ResponseEntity.ok(null);
	}
	
	@RequestMapping(value = "/test", method = RequestMethod.GET)
	private ResponseEntity<?> test() 
	{
		return ResponseEntity.ok("success");
	}
	
	
}
