package sequro.filedownload;

import java.io.File;
import java.io.FileInputStream;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.fasterxml.jackson.databind.ObjectMapper;


@SpringBootApplication
public class FileDownloaderApplication 
{

	public static void main(String[] args) {
		SpringApplication.run(FileDownloaderApplication.class, args);
		//show();
		//createBase64Images();
	}
	
	@Bean("mapper")
	public ObjectMapper mapper() {
		ObjectMapper mapper = new ObjectMapper();
		return mapper;
	}
	
	static void createBase64Images() 
	{
		try
		{
			byte[] fileContent = FileUtils.readFileToByteArray(new File("E:\\Sequro\\Speta\\logo\\Capture11.PNG"));
			
			String encodeString = Base64.getEncoder().encodeToString(fileContent);
			
			System.out.println(encodeString);
		}
		catch (Exception e) {
		}
	}
	
	static void show()
	{
		Map<String, String> resultMapdata = new HashMap<>();
		resultMapdata.put("id", "1");
		resultMapdata.put("name", "abc");
		
		Map<String, Object> data = new HashMap<>();
        Customer customer = new Customer();
        customer.setCompanyName("Simple Solution");
        customer.setContactName("John Doe");
        customer.setAddress("123, Simple Street");
        customer.setEmail("john@simplesolution.dev");
        customer.setPhone("123 456 789");
        data.put("header", customer);
		
		System.out.println(data);
	}
	
	
}
